import {css}from 'lit-element';

export default css`
h2{
    position:relative;
     top:40px;
    color:blue;
    font-family: "Courier New", Courier, monospace;


}
nav{
    position:relative;
  top:45px;
}
`