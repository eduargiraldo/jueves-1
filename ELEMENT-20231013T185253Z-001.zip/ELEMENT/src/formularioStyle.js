import {css}from 'lit-element';

export default css`
h2{
  position:relative;
  left:40%;

    color:blue;
    font-family: "Courier New", Courier, monospace;

}

form{
  position:relative;
  top:40px;
  left:40%;
}
input[type=text] {
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 2px solid red;
  border-radius: 4px;
}
input[for="lname"]{
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 2px solid red;
  border-radius: 4px;

}
input[type=submit] {
  color:blue;
}

  
  
  
  
 
 
`