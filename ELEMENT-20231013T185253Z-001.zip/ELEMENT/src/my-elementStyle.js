import {css}from 'lit-element';

export default css`
h1{
    color:blue;
    font-family: "Courier New", Courier, monospace;

}

li,ul{
    font-family: "Courier New", Courier, monospace;


}


`